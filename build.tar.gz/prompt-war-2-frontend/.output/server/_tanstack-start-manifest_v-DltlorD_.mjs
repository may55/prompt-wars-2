//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DltlorD_.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/Users/mayanksoni/Projects/prompt-wars-2/prompt-war-2-frontend/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-DWBmVj6Z.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DWBmVj6Z.js"
		} }]
	},
	"/": {
		filePath: "/Users/mayanksoni/Projects/prompt-wars-2/prompt-war-2-frontend/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BW-NdWrf.js"]
	}
} });
//#endregion
export { tsrStartManifest };
